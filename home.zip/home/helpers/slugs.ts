export const getSlugName = (category: string, project: string) => {
    return `${category.toLowerCase().replaceAll(" ", "-")}/${project.toLowerCase().replaceAll(" ", "-")}`
}