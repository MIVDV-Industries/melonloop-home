export const paths = {
  SeedIconPath: '/Seed.png'
}