import { FC, useEffect, useState } from "react";
import Image from "next/image";
import { Button } from "../Buttons/Button";
import classnames from "classnames";
import { Socials, HamburgerIcon, Portal, MobileMenu } from "components";
import { useWindowSize } from "hooks/useWindowSize";

interface IHeaderProps {
  activeSection: string;
  showButton?: boolean;
  showContactSection?: () => void;
}

export const Header: FC<IHeaderProps> = ({
  activeSection,
  showContactSection,
  showButton = true,
}) => {
  const isHome = activeSection === "home";
  const [showMenu, setShowMenu] = useState<boolean>(false);

  const linksClassNames = classnames("header-links", {
    "has-gap": !isHome && showButton,
  });

  const btnClassNames = classnames("offscreen-button", {
    "show-button": !isHome && showButton,
  });

  const handleShowMenu = () => {
    setShowMenu(!showMenu);
  };

  const { width } = useWindowSize();

  return (
    <header>
      <a href="#home">
        <Image
          src="/Logo.svg"
          alt="melonloop"
          width={200}
          height={41}
          priority={true}
        />
      </a>
      {!!width && width > 780 ? (
        <div className={linksClassNames}>
          <Socials
            className="header-icons"
            instagram="https://www.example.com"
            linkedin="https://www.linkedin.com/company/melonloop/"
            facebook="https://www.example.com"
          />
          <div className={btnClassNames}>
            <Button
              text="Contact Us"
              size="small"
              type="normal"
              onClick={showContactSection}
              tabIndex={isHome ? -1 : 0}
            />
          </div>
        </div>
      ) : (
        <>
          <div onClick={handleShowMenu}>
            <HamburgerIcon />
          </div>
          <Portal show={showMenu}>
            <MobileMenu close={handleShowMenu} />
          </Portal>
        </>
      )}
    </header>
  );
};
