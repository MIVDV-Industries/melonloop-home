import { ChevronIcon, NavLink } from "components";
import sectionsData from "data/sections.json"
import { FC, MutableRefObject, RefObject, useEffect, useRef } from "react"
import classnames from 'classnames'

interface INavProps {
  activeSection: string;
  sectionsRef?: MutableRefObject<RefObject<Element>[]>;
}

export const Nav: FC<INavProps> = ({ activeSection, sectionsRef }) => {
  const wrapperRef = useRef<HTMLDivElement>(null)
  const navRef = useRef<HTMLElement>(null)

  // 'O mizerie' - Novac Emil
  const centerActiveLink = () => {
    // Get activeLink - don't think useRef is necessary here since the `active` link keeps changing
    const activeLink = document.querySelector(
      ".nav-link.active"
    ) as HTMLAnchorElement | null

    if (!wrapperRef.current || !activeLink) return
    const wrapperMid = Number(wrapperRef.current.offsetWidth / 2)
    const activeLinkMid = Number(activeLink?.offsetWidth / 2)

    const leftOffset = activeLink.offsetLeft
    const newPos = wrapperMid - (leftOffset + activeLinkMid)

    if (navRef.current) {
      navRef.current.style.transform = `translateX(${newPos}px)`
    }
  }

  const handleSectionSelection = (index: number) => {
    if (index === -1) return
    sectionsRef!.current[index].current?.scrollIntoView()
  }

  const handleArrowClick = (direction: "right" | "left") => {
    const currentIndex = sectionsData.sectionNames.findIndex((el) => el === activeSection)

    if (currentIndex < 0) return

    if (direction === "right") {
      handleSectionSelection(currentIndex + 1 < sectionsData.sectionNames.length ? currentIndex + 1 : -1)
    } else {
      handleSectionSelection(currentIndex - 1 >= 0 ? currentIndex - 1 : -1)
    }
  }

  useEffect(() => {
    window.addEventListener("resize", centerActiveLink)

    return () => window.removeEventListener("resize", centerActiveLink)
  }, [])

  useEffect(() => {
    if (window.innerWidth > 768) centerActiveLink()
    else {
      const activeLinkRef = document.querySelector(
        ".nav-link.active"
      ) as HTMLAnchorElement

      setTimeout(() => activeLinkRef?.scrollIntoView({
        behavior: "smooth",
        inline: 'center'
      }), 150)
    }

  }, [activeSection])

  return (
    <div className="nav-container">
      <h6 className="copyright">&copy;Melonloop {new Date().getFullYear()}</h6>
      <ArrowButton direction="left" onClick={() => handleArrowClick('left')} className={sectionsData.sectionNames[0] !== activeSection ? "show" : "hide"} />
      <div className="nav-wrapper" ref={wrapperRef}>
        <nav ref={navRef}>
          {sectionsData.sectionNames.map((name, index) => (
            <NavLink
              key={name}
              name={name}
              activeSection={activeSection}
              onClick={() => handleSectionSelection(index)} />
          ))}
        </nav>
      </div>
      <ArrowButton direction="right" onClick={() => handleArrowClick('right')} className={sectionsData.sectionNames[sectionsData.sectionNames.length - 1] !== activeSection ? "show" : "hide"} />
    </div>
  )
}

interface IArrowButtonProps {
  direction: "left" | "right";
  onClick: () => void;
  className?: string;
}

const ArrowButton: FC<IArrowButtonProps> = ({ direction, onClick, className }) => {

  const classNames = classnames('arrow-btn', direction, className)

  return <div className={classNames} onClick={onClick}><ChevronIcon /></div>
}