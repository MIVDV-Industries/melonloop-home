import { BackButton } from "components/Buttons"
import { FC } from 'react'
import classnames from 'classnames'
 
interface ISimpleHeaderProps {
    title: string;
    classNames?: string;
    onBack: () => void
}

export const SimpleHeader: FC<ISimpleHeaderProps> = ({title, classNames, onBack}) => {

  const simpleHeaderClassNames = classnames('simpleHeader', classNames)

  return (
      <div className={simpleHeaderClassNames}>
        <BackButton onClick={onBack} />
        <h3 className="simpleHeader-title">{title}</h3>
      </div>
  )
}
