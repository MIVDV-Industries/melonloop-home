import { FC } from "react";
import { IInputBase } from "./types";

export const TextInput: FC<IInputBase> = ({ name, label, placeholder, value, onChange }) => {
    return (
        <label htmlFor={name}>
            {label}
            <input
                type="text"
                className="textInput"
                name={name}
                placeholder={placeholder}
                value={value}
                onChange={onChange}
            />
        </label>
    )
}
