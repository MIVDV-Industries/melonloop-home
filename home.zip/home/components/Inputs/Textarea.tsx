import { FC } from "react"
import { IInputBase } from "./types"

export const Textarea: FC<IInputBase> = ({ name, label, placeholder, value, onChange }) => {
    return (
        <label htmlFor={name}>
            {label}
            <textarea
                name={name}
                value={value}
                onChange={onChange}
                placeholder={placeholder}
                rows={10}
            ></textarea>
        </label>
    )
}
