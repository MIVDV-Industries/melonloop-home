import { FacebookIcon, InstagramIcon, LinkedInIcon } from 'components'
import { FC } from 'react'

interface ISocialsProps {
    className?: string;
    linkedin?: string;
    instagram?: string;
    facebook?: string;
}

export const Socials: FC<ISocialsProps> = ({ className, linkedin, instagram, facebook }) => {
    return (
        <div className={className}>
            {linkedin &&
                <a href={linkedin} target="_blank" rel="noreferrer">
                    <LinkedInIcon />
                </a>
            }
            {instagram &&
                <a href={instagram} target="_blank" rel="noreferrer">
                    <InstagramIcon />
                </a>
            }
            {facebook &&
                <a href={facebook} target="_blank" rel="noreferrer">
                    <FacebookIcon />
                </a>
            }
        </div>
    )
}
