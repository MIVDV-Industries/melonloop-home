import { AnimatePresence, motion } from "framer-motion";
import { FC } from "react";
import { Button } from "../Buttons/Button";
import { ISubSectionProps } from "./types";
import sectionsData from 'data/sections.json'

export const HomeSection: FC<ISubSectionProps> = ({ parentRef, showPortal }) => {

  const heroTextLetters = Array.from(sectionsData.home.heroText)

  const heroTextVariants = {
    hidden: { opacity: 0 },
    visible: (i = 1) => ({
      opacity: 1,
      transition: { staggerChildren: 0.03, delayChildren: 0.04 * i }
    })
  }

  const heroTextLetterVariants = {
    visible: {
      opacity: 1,
      x: 0,
      y: 0,
      transition: {
        type: "spring",
        damping: 12,
        stiffness: 100,
      }
    },
    hidden: {
      opacity: 0,
      x: -20,
      y: 10,
    }
  }

  const heroDescriptionVariants = {
    visible: {
      opacity: 1,
      x: 0,
      y: 0,
      transition: {
        delay: 2.5,
        duration: 0.65
      }
    },
    hidden: {
      opacity: 0,
      x: 0,
      y: 200,
    }
  }

  return (
    <section className="home-section" id="home" ref={parentRef}>
      <div className="section-body">
        <AnimatePresence>
          <motion.div
            key="hero-text"
            className="h1 hero-text"
            variants={heroTextVariants}
            initial="hidden"
            animate="visible"
          >
            {heroTextLetters.map((letter, index) => (
              <motion.span variants={heroTextLetterVariants} key={letter + index}>
                {letter}
              </motion.span>
            ))}
          </motion.div>
          <motion.div
            key="hero-description"
            className="hero-description"
            variants={heroDescriptionVariants}
            initial="hidden"
            animate="visible"
          >
            <h4>
              {sectionsData.home.heroDesc}
            </h4>
            <Button
              type="normal"
              size="large"
              text="Contact Us"
              onClick={showPortal}
            />
          </motion.div>
        </AnimatePresence>
      </div>
    </section>
  )
}
