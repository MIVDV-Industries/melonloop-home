import { Button, ChevronIcon, Portal, Projects, Slider } from "components";
import type { IImage } from "components/Slider/Slider";
import { FC, useState, useEffect, useRef } from "react";
import { ISubSectionProps } from "./types";
import articleSections from "data/projectArticles.json";
import classnames from "classnames";
import Link from "next/link";
import { getSlugName } from "helpers/slugs";

export interface IProjectArticles {
  name: string;
  type: string;
  desc: string;
  image: IImage;
}

export interface IArticleSection {
  name: string;
  projects: IProjectArticles[];
}

interface IArticle {
  article: IArticleSection;
  isActive: boolean;
  showProject: () => void;
}

// TODO: Articles should be handled dyncamically just in case more will be added
export const WhatWeDoSection: FC<ISubSectionProps> = ({ parentRef }) => {
  const articlesWrapper = useRef<HTMLDivElement>(null);
  const [activeArticle, setActiveArticle] = useState(0);
  const [showProject, setShowProject] = useState(false);
  const [hideNav, setHideNav] = useState(false);

  useEffect(() => {
    if (!articlesWrapper) return;

    if (activeArticle === 0) {
      articlesWrapper.current!.style.transform = "translateX(0)";
    } else {
      articlesWrapper.current!.style.transform = `translateX(-100vw)`;
    }
  }, [activeArticle]);

  const showProjectsSection = () => {
    setHideNav(true);
    setShowProject(true);
    setTimeout(() =>
      window.scrollTo({ top: window.innerHeight, behavior: "smooth" })
    );
  };

  const hideProjectsSection = () => {
    setHideNav(false);
    window.scrollTo({ top: 0, behavior: "smooth" });
    setTimeout(() => setShowProject(false), 700);
  };

  return (
    <>
      <section className="whatWeDo-section" id="what-we-do" ref={parentRef}>
        <div className="section-header">
          <h2 className="section-title">What we do</h2>
          <h4 className="section-description">
            <Button
              size="small"
              type="round"
              text="Web Development"
              isSelected={activeArticle === 0}
              onClick={() => setActiveArticle(0)}
            />
            <Button
              size="small"
              type="round"
              text="UI &amp; UX Design"
              isSelected={activeArticle === 1}
              onClick={() => setActiveArticle(1)}
            />
          </h4>
        </div>
        <div className="section-body">
          <div className="articles-wrapper" ref={articlesWrapper}>
            <Article
              article={articleSections[0]}
              isActive={activeArticle === 0}
              showProject={showProjectsSection}
            />
            <Article
              article={articleSections[1]}
              isActive={activeArticle === 1}
              showProject={showProjectsSection}
            />
          </div>
        </div>
      </section>
      <Portal show={showProject} hideNav={hideNav}>
        <Projects
          article={articleSections[activeArticle]}
          onBack={hideProjectsSection}
        />
      </Portal>
    </>
  );
};

const Article: FC<IArticle> = ({ article, isActive, showProject }) => {
  const [currentProject, setCurrentProject] = useState<IProjectArticles>(
    article.projects[0]
  );
  const images = article.projects.map((project) => project.image);

  const articleClassNames = classnames("whatWeDo-article", {
    active: isActive,
  });

  const slug = getSlugName(article.name, currentProject.name);

  return (
    <article className={articleClassNames}>
      <div className="projects-article">
        <div className="project-details">
          <Link href={`projects/${slug}`}>
            <div className="project-details-header">
              <h3 className="project-name">{currentProject?.name}</h3>
              <h4 className="project-type">{currentProject?.type}</h4>
            </div>
          </Link>
          <h4 className="project-desc">{currentProject?.desc}</h4>
        </div>
        <Slider
          images={images}
          setSlide={(index: number) =>
            setCurrentProject(article.projects[index])
          }
        />
      </div>
      <Button
        size="large"
        type="normal"
        text="View all Projects"
        icon={<ChevronIcon />}
        onClick={showProject}
      />
    </article>
  );
};
