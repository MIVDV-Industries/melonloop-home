import { FC, useState } from "react";
import { ISubSectionProps } from "./types";
import partners from "data/partners.json";
import { Portal, OverlayCard } from "components";

interface IPartner {
	name: string;
	desc: string;
	img: string;
	backgroundColor?: string;
}

interface IPartnerCardProps {
	partner: IPartner;
	onClick: (partner: IPartner) => void;
	color: string;
}

export const PartnersSection: FC<ISubSectionProps> = ({ parentRef }) => {
	const [selectedPartner, setSelectedPartner] = useState<IPartner | null>(null);

	const handlePartnerSelection = (partner: IPartner) => {
		// 768px = 48em
		if (window.innerWidth < 768) setSelectedPartner(partner);
	};

	const handleClose = () => setSelectedPartner(null);

	return (
		<>
			<section className="partners-section" id="partners" ref={parentRef}>
				<div className="section-header">
					<h2 className="section-title">Partners</h2>
					<h4 className="section-description">
						Our friendly partners we’re working with
					</h4>
				</div>
				<div className="section-body">
					<div className="partners-wrapper">
						{partners.map((partner, index) => (
							<PartnerCard
								key={partner.name + index}
								partner={partner}
								color={partner.backgroundColor ?? "white"}
								onClick={handlePartnerSelection}
							/>
						))}
					</div>
				</div>
			</section>
			<Portal
				show={selectedPartner !== null && window.innerWidth < 768}
				hideNav={false}
			>
				<OverlayCard onClose={handleClose} data={selectedPartner} color={selectedPartner?.backgroundColor} isPartner={true} />
			</Portal>
		</>
	);
};


const PartnerCard: FC<IPartnerCardProps> = ({ partner, onClick, color }) => {
	return (
		<div
			className={`partner-card-wrapper ${color}`}
			onClick={() => onClick(partner)}
		>
			<div className="info-layer">
				<h5>{partner.name}</h5>
				<p className="partner-desc">{partner.desc}</p>
			</div>

			<picture>
				<source srcSet={partner.img}/>
				<img src={partner.img} alt={partner.name} style={{width:"100px", height:"112px"}}/>
			</picture>
		</div>
	);
};
