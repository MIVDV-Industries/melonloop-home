export { HomeSection } from "./HomeSection"
export { WhatWeDoSection } from "./WhatWeDoSection"
export { TechSection } from "./TechSection"
export { TeamSection } from "./TeamSection"
export { PartnersSection } from "./PartnersSection"
export { Section } from './SectionResolver'

