import { MutableRefObject } from "react";

export interface ISectionProps {
  name: string;
  parentRef: MutableRefObject<HTMLElement | null>;
  showPortal?: () => void;
}

export type ISubSectionProps = Omit<ISectionProps, "name">;

export interface Member {
  imageUrl: string;
  name: string;
  role: string;
  description: string;
  facebook: string;
  linkedin: string;
  instagram: string;
  isSelected: boolean;
}
