import { FC, useCallback, useEffect, useMemo, useState } from "react"
import { ISubSectionProps, Member } from "./types"
import { HoverableCard, PlaceholderCard, Portal, OverlayCard } from "components"
import { motion } from "framer-motion"
import teamMembers from "data/team.json";

export const TeamSection: FC<ISubSectionProps> = ({ parentRef, showPortal }) => {
  const [members, setMembers] = useState<(Member & { isSelected?: boolean })[]>(teamMembers.members);
  const [isAnySelected, setIsAnySelected] = useState<Member>();
  const [screenW, setScreenW] = useState<number>(0)

  useEffect(() => {
    setScreenW(window?.innerWidth);

    if (window)
      window.addEventListener("resize", () => setScreenW(window?.innerWidth))

    return ()=>{
      window.removeEventListener("resize", () => setScreenW(window?.innerWidth))
      }
  }, [])

  const animationVariants = useMemo(() => {
    if (screenW)
      return {
        "bottom": {
          y: "15%",
          transition: {
            y: {
              duration: 0.2,
            }
          }
        }
      }

    else return undefined
  }, [screenW])

  const handleSelectedMember = useCallback((member: Member) => {
    let isAnySelected = null;
    const newMembers = [...members].map(arrayMember => {
      arrayMember.isSelected = arrayMember.imageUrl === member.imageUrl;
      if (arrayMember.isSelected)
        isAnySelected = { ...arrayMember };
      return arrayMember;
    });
    setMembers(newMembers);
    isAnySelected && setIsAnySelected(isAnySelected);
  }, [members])

  const handleClickOutside = useCallback((clickEvent?: any) => {
    if (["card-container", "team-section"].includes(clickEvent?.target?.className)
      || ["path", "svg"].includes(clickEvent.target[Object.keys(clickEvent.target)[0]].type)) {
      const updatedMembers = [...members].map((member: Member) => ({ ...member, isSelected: false }))
      setMembers(updatedMembers);
      setIsAnySelected(undefined);
    }
  }, [members])

  return (
    <section className="team-section" id="team" ref={parentRef} onClick={handleClickOutside}>
      <div className="section-header">
        <h2 className="section-title">The team</h2>
        <h4 className="section-decription">The ones making all this possible</h4>
      </div>
      <motion.div
        animate={isAnySelected && screenW > 1380 ? "bottom" : "top"}
        variants={animationVariants}
        className={`card-container`}>
        {
          members.map((member, index: number) => {
            return (<HoverableCard key={member.imageUrl} index={index} isSelected={member.imageUrl === isAnySelected?.imageUrl && screenW > 1380} member={member} isAnySelected={!!isAnySelected} handleSelectedMember={handleSelectedMember} />)
          }
          )
        }
        <PlaceholderCard isAnySelected={!!isAnySelected} handleClick={showPortal} />
      </motion.div>
      <Portal
        show={!!isAnySelected && screenW < 1380}
        hideNav={true}
      >
        <OverlayCard onClose={handleClickOutside} data={isAnySelected} isPartner={false} />
      </Portal>
    </section>
  )
}
