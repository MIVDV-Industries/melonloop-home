import React, { FC, useCallback, useId, useState, useEffect } from "react";
import { ISubSectionProps } from "./types";
import technologies from 'data/technologies.json';

export const TechSection: FC<ISubSectionProps> = ({ parentRef }) => {
  const id = useId();
  const [selectedTech, setSelectedTech] = useState<number | null>(null)

  const handleSelection = (index: number) => setSelectedTech(prevIndex => {
    if (prevIndex === index) return null
    else return index;
  });

  // TODO: Allow a max of 2 large per side (left/right)
  const randomSize = useCallback(() => {
    const options = ['small', 'medium', 'large'] // matching the class names
    const min = 0;
    const max = options.length - 1;
    const result = Math.floor(Math.random() * (max - min + 1) + min)

    return options[result]
  }, [])

  return (
    <section className="tech-section" id="tech" ref={parentRef}>
      <div className="section-header">
        <h2 className="section-title">Technologies</h2>
        <h4 className="section-description">
          We’re familiar with bla bla cool text about how cool cuz we can handle
          the latest tech trends.
        </h4>
      </div>
      <div className="section-body">
        <div className="left">
          {technologies.map((tech, index) => {
            if (index < 6)
              return <TechItem key={id + tech.title} selectedTech={selectedTech} randomSize={randomSize} index={index} handleSelection={handleSelection} tech={tech} />
            else return null
          })}
        </div>
        <div className="right">
          {technologies.map((tech, index) => {
            if (index >= 6) {
              return <TechItem key={id + tech.title} selectedTech={selectedTech} randomSize={randomSize} index={index} handleSelection={handleSelection} tech={tech} />
            }
            else return null
          })}
        </div>
      </div>
    </section>
  )
}

interface TechItemProps {
  index: number;
  selectedTech: number | null;
  randomSize: () => string
  handleSelection: (index: number) => void
  tech: {
    title: string;
    desc: string;
  }
}

const TechItem: FC<TechItemProps> = ({ index, selectedTech, tech, handleSelection, randomSize }) => {
  const [size, setSize] = useState("")

  useEffect(() => {
    setSize(randomSize())
  }, [randomSize])


  return (
    <div onClick={() => handleSelection(index)} className={`tech-wrapper ${selectedTech === index ? 'active' : ''}`}>
      <span className={size}>{tech.title}</span>
      <div className="description-wrapper">
        <p>{tech.desc}</p>
      </div>
    </div>)
}
