import { FC } from "react"
import {
  HomeSection,
  WhatWeDoSection,
  TechSection,
  TeamSection,
  PartnersSection,
} from "."
import { ISectionProps } from "./types";

export const Section: FC<ISectionProps> = ({ name, parentRef, showPortal }) => {
  switch (name) {
    case "home":
      return <HomeSection parentRef={parentRef} showPortal={showPortal} />
    case "what-we-do":
      return <WhatWeDoSection parentRef={parentRef} />
    case "tech":
      return <TechSection parentRef={parentRef} />
    case "partners":
      return <PartnersSection parentRef={parentRef} />
    case "team":
      return <TeamSection parentRef={parentRef} showPortal={showPortal} />
    default:
      return null
  }
}
