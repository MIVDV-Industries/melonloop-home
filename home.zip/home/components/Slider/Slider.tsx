import { FC, useCallback, useEffect, useState, useRef } from "react";
import Image from "next/image";

export interface IImage {
  src: string;
  alt: string;
  className?: string;
}

interface IImageSliderProps {
  images: IImage[];
  transitionInterval?: number;
  setSlide?: (index: number) => void;
}

// 'Alta mizerie' - Novac Emil
export const Slider: FC<IImageSliderProps> = ({
  images,
  transitionInterval = 3000,
  setSlide,
}) => {
  const sliderRef = useRef<HTMLDivElement>(null);
  const [currentSlideIndex, setCurrentSlideIndex] = useState<number>(0);
  const sizeRef = useRef<{ offsetWidth: number, offsetMargin: number } | null>(null)

  if (transitionInterval < 1000) transitionInterval = 1000

  const slideImages = useCallback(() => {
    const slideToBe = currentSlideIndex === images.length - 1 ? 0 : currentSlideIndex + 1

    if (!sliderRef.current) return
    sliderRef.current.style.transform = `translateX(-${sizeRef.current!.offsetWidth + sizeRef.current!.offsetMargin}px)`

    setSlide && setSlide(slideToBe)
    setCurrentSlideIndex(slideToBe)
  }, [images, currentSlideIndex, setSlide, sizeRef]);

  const sliderTransitionStartListener = () => {
    if (!sliderRef.current) return;
    const firstChildCopy = sliderRef.current.firstElementChild?.cloneNode(true);
    sliderRef.current.appendChild(firstChildCopy as Node);
  }

  const sliderTransitionEndListener = () => {
    if (!sliderRef.current) return;
    sliderRef.current.removeChild(sliderRef.current.firstChild as Node);
    sliderRef.current.style.transition = 'none';
    sliderRef.current.style.transform = 'translateX(0)';
    setTimeout(() => {
      sliderRef.current!.style.transition = 'all 1s var(--almost-ease-in-out)';
    })
  }

  // INITIALIZE
  useEffect(() => {
    // Because useEffect wanted the refs to be 'copied' to variables
    const sliderRefCopy = sliderRef.current;

    handleResize();
    window.addEventListener("resize", handleResize)
    sliderRefCopy?.addEventListener('transitionstart', sliderTransitionStartListener)
    sliderRefCopy?.addEventListener('transitionend', sliderTransitionEndListener)


    return () => {
      window.removeEventListener("resize", handleResize)
      sliderRefCopy?.removeEventListener('transitionstart', sliderTransitionStartListener);
      sliderRefCopy?.removeEventListener('transitionend', sliderTransitionEndListener);
    }
  }, [])

  // TRANSITION INTERVAL
  useEffect(() => {
    const interval = setInterval(slideImages, transitionInterval)

    return () => clearInterval(interval)
  }, [slideImages, transitionInterval]);


  const handleResize = () => {
    const firstChild = sliderRef.current?.firstElementChild as HTMLDivElement;
    sizeRef.current = {
      offsetWidth: firstChild.offsetWidth,
      offsetMargin: Number(window.getComputedStyle(firstChild as Element).marginRight.replace('px', ''))
    }
  }

  return (
    <div className="slider-wrapper">
      <div className="slider" ref={sliderRef}>
        {images.map((image, index) => {
          return (
            <div key={index} className="slider-item" data-current-slide={index === currentSlideIndex}>
              <Image src={image.src} alt={image.alt} layout="fill" priority={true} />
            </div>
          );
        })}
      </div>
    </div>
  );
};
