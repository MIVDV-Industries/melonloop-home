import { FC } from 'react'
import classnames from 'classnames'

interface INavLinkProps {
    name: string;
    activeSection?: string;
    onClick: () => void;
    className?: string;
}

export const NavLink: FC<INavLinkProps> = ({ name, activeSection, onClick, className }) => {

    if (!name) return null

    const navLinkClassnames = classnames('nav-link', className, {
        "active": name === activeSection
    })

    return (
        <a
            key={name}
            id={`link-${name}`}
            onClick={onClick}
            className={navLinkClassnames}
            href={`#${name}`}
        >
            {name?.replaceAll("-", " ")}
        </a>
    )
}
