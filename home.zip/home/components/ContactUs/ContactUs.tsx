import { FC, useState } from "react";
import {
  BackButton,
  Button,
  CallIcon,
  ChatIcon,
  MailIcon,
  Socials,
  TextInput,
  Textarea,
  SimpleHeader
} from "components";

interface IContact {
  isContact?: boolean;
  onBack: () => void;
}

interface FormData {
  name: string;
  email: string;
  message: string;
}

export const ContactUs: FC<IContact> = ({ isContact = true, onBack }) => {
  const [formData, setFormData] = useState<FormData>({
    name: "",
    email: "",
    message: "",
  });

  const handleInputChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>
  ) => {
    setFormData((prevData) => ({
      ...prevData,
      [e.target.name]: e.target.value,
    }));
  };

  const title = isContact ? "Contact Us" : "Join Us";
  const handleContactSubmit = (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    fetch("/api/sendMail", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(formData),
    });
  };
  return (
    <div className="contact-section">
      <SimpleHeader title={title} onBack={onBack} classNames="contact-header" />
      <div className="contact-body">
        <div className="contact-details">
          {isContact ? (
            <h1>Have a project? We would love to help!</h1>
          ) : (
            <h1>Wanna be part of our team? We would love that!</h1>
          )}

          <div className="contact-info">
            <div className="contact-info-item">
              <CallIcon />
              <h4>
                Call us at <span>+00 000 000 000</span>
              </h4>
            </div>
            <div className="contact-info-item">
              <MailIcon />
              <h4>
                Email us at <span>contact@melonloop.com</span>
              </h4>
            </div>
            <div className="contact-info-item">
              <ChatIcon />
              <h4>Find us here:</h4>
              <Socials
                className="header-icons"
                instagram="https://www.example.com"
                linkedin="https://www.linkedin.com/company/melonloop/"
                facebook="https://www.example.com"
              />
            </div>
          </div>
        </div>
        <form className="contact-form" onSubmit={handleContactSubmit}>
          <TextInput
            name="name"
            placeholder="Name"
            value={formData.name}
            onChange={handleInputChange}
          />
          <TextInput
            name="email"
            placeholder="email"
            value={formData.email}
            onChange={handleInputChange}
          />
          <Textarea
            name="message"
            placeholder="message"
            value={formData.message}
            onChange={handleInputChange}
          />
          <Button
            text="Send message"
            type="normal"
            size="large"
            onClick={undefined}
          />
        </form>
      </div>
    </div>
  );
};
