import { FC } from "react"
import classnames from "classnames"

export interface IButtonProps {
  text: string;
  size: "small" | "large" | "huge";
  type: "normal" | "round";
  onClick: (() => void) | undefined;
  icon?: JSX.Element;
  isReverse?: boolean;
  isSelected?: boolean;
  isDisabled?: boolean;
  tabIndex?: number;
}

export const Button: FC<IButtonProps> = ({
  text,
  size,
  type,
  onClick,
  icon,
  isReverse = false,
  isSelected = false,
  isDisabled = false,
  tabIndex,
}) => {
  const btnClassNames = classnames(`btn btn-${size} btn-${type}`, {
    "btn-reverse-icon": isReverse,
    "btn-selected": isSelected,
    "btn-disabled": isDisabled,
  })

  return (
    <button
      className={btnClassNames}
      onClick={onClick}
      disabled={isDisabled}
      tabIndex={tabIndex}
    >
      <span className="front">
        {text}
        {icon && <div className="btn-icon">{icon}</div>}
      </span>
    </button>
  )
}
