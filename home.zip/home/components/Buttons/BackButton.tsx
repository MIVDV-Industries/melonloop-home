import BackIcon from "components/Icons/BackIcon"
import { FC } from "react"

interface BackButton {
  onClick: () => void
}

export const BackButton: FC<BackButton> = ({ onClick }) => {
  return (
    <button className="btn btn-back" onClick={onClick}>
      <div className="btn-icon">
        <BackIcon />
      </div>
      <span>Back</span>
    </button>
  )
}
