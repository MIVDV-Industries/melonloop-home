import { CloseIcon, Button, Socials, NavLink } from 'components'
import React, { FC } from 'react'
import sectionsData from "data/sections.json"

interface IMobileMenu {
  close: () => void
}

export const MobileMenu: FC<IMobileMenu> = ({ close }) => {

  const handleSelection = () => {
    close();
  }

  const variants = {
    hidden: {
      y: "-100vh",
      opacity: 0
    },
    visible: {
      y: "0",
      opacity: 1,
      transition: {
        duration: 0.3
      }
    },
    exit: {
      y: "100vh",
      opacity: 0
    }
  }

  return (
    <div className='mobile-menu-wrapper'>
      <div className='close-icon-mobile-menu'>
        <CloseIcon onClick={close} />
      </div>
      <div className='mobile-menu-options'>
        {sectionsData.sectionNames.map((name, index) => (
          <NavLink
            key={name}
            name={name}
            onClick={handleSelection}
          />
        ))}
      </div>
      <div className='mobile-menu-footer'>
        <Button
          type="normal"
          size="huge"
          text="Contact Us"
          onClick={undefined}
        />
        <Socials className="mobile-icons"
          instagram="https://www.example.com"
          linkedin="https://www.linkedin.com/company/melonloop/"
          facebook="https://www.example.com" />
        <h6>&copy;Melonloop {new Date().getFullYear()}</h6>
      </div>
    </div>
  )
}
