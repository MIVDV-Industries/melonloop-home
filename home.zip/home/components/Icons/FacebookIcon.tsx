import { SVGProps } from "react"

export const FacebookIcon = (props: SVGProps<SVGSVGElement>) => {
  return (
    <svg
      width={24}
      height={24}
      fill="currentColor"
      xmlns="http://www.w3.org/2000/svg"
      {...props}
    >
      <path
        fillRule="evenodd"
        clipRule="evenodd"
        d="M4.364 0A4.364 4.364 0 0 0 0 4.364v15.272A4.364 4.364 0 0 0 4.364 24h15.272A4.364 4.364 0 0 0 24 19.636V4.364A4.364 4.364 0 0 0 19.636 0H4.364Zm8.276 24v-9.383h-2.481V11.24h2.48V8.354c0-2.267 1.467-4.349 4.844-4.349 1.367 0 2.378.131 2.378.131l-.08 3.155s-1.03-.01-2.156-.01c-1.218 0-1.413.561-1.413 1.493v2.466h3.666l-.16 3.378h-3.506V24H12.64Z"
        fill="#FF6759"
      />
    </svg>
  )
}
