import { SVGProps } from "react"

export const LinkedInIcon = (props: SVGProps<SVGSVGElement>) => {
  return (
    <svg
      width={24}
      height={24}
      fill="currentColor"
      xmlns="http://www.w3.org/2000/svg"
      {...props}
    >
      <path
        fillRule="evenodd"
        clipRule="evenodd"
        d="M4.364 0A4.364 4.364 0 0 0 0 4.364v15.272A4.364 4.364 0 0 0 4.364 24h15.272A4.364 4.364 0 0 0 24 19.636V4.364A4.364 4.364 0 0 0 19.636 0H4.364Zm8.386 9.15H9.5V20.65H13v-5.57c0-1.867.687-3.055 2.34-3.055 1.19 0 1.66 1.102 1.66 3.055v5.57h3.498v-6.352c0-3.428-.82-5.297-4.276-5.297-1.804 0-3.004.844-3.473 1.783V9.15ZM7 20.5H3.5V9H7v11.5Zm.343-14.374a2.25 2.25 0 1 0-4.187-1.654 2.25 2.25 0 0 0 4.187 1.654Z"
        fill="#FF6759"
      />
    </svg>
  )
}
