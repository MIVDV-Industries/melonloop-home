import { SVGProps } from "react"

export const BackIcon = (props: SVGProps<SVGSVGElement>) => (
  <svg
    width={19}
    height={17}
    fill="currentColor"
    xmlns="http://www.w3.org/2000/svg"
    {...props}
  >
    <path d="M8.295 15.716A1 1 0 0 0 9.7 14.291L4.33 9h13.67a1 1 0 1 0 0-2H4.336L9.7 1.715A1 1 0 0 0 8.295.29L1.371 7.113a1.25 1.25 0 0 0 0 1.78l6.924 6.823Z" />
  </svg>
)

export default BackIcon
