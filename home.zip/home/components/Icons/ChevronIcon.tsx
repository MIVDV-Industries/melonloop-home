import { SVGProps } from "react"

export const ChevronIcon = (props: SVGProps<SVGSVGElement>) => (
  <svg
    width={16}
    height={10}
    fill="currentColor"
    xmlns="http://www.w3.org/2000/svg"
    {...props}
  >
    <path
      d="M15.707.793a1 1 0 0 0-1.414 0L8 7.086 1.707.793A1 1 0 0 0 .293 2.207l7 7a1 1 0 0 0 1.414 0l7-7a1 1 0 0 0 0-1.414Z"
      fill="#FF6759"
    />
  </svg>
)
