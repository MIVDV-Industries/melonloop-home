import { CloseIcon, Socials } from "components";
import { AnimatePresence, motion } from "framer-motion";
import { FC } from "react";
import Image from "next/image";
import classnames from 'classnames'

// TODO: Change 'any' when types are defined
interface ICardProps {
	onClose: () => void
	data: any
	color?: string
	isPartner: boolean
}

export const OverlayCard: FC<ICardProps> = ({ onClose, data, color, isPartner }) => {

	const variants = {
		hidden: {
			y: "-100vh",
			opacity: 0
		},
		visible: {
			y: "0",
			opacity: 1,
			transition: {
				duration: 0.3
			}
		},
		exit: {
			y: "100vh",
			opacity: 0
		}
	}

	const cardClassnames = classnames("mobile-info-card", color ?? "white", {
		"isPartner": isPartner
	})

	return (
		<AnimatePresence mode="wait">
			<motion.div className="mobile-info-card-wrapper" exit={{ opacity: 0 }}>
				<motion.div
					className={cardClassnames}
					variants={variants}
					initial="hidden"
					animate="visible"
					exit="exit"
				>
					{!isPartner &&
						<div style={{ marginBottom: "1em" }}>
							<Image
								src={data?.imageUrl}
								alt="member-pic"
								priority={true}
								width={157}
								height={157}
								style={{ borderRadius: "10px" }}
							/>
						</div>
					}
					<h5 className={`card-title ${isPartner ? "card-black" : ""}`}>{data?.name}</h5>
					<h6 className="card-role">{data?.role}</h6>
					<p className="card-desc">{data?.desc || data?.description}</p>
					{!isPartner &&
						<Socials
							className="card-icons"
							instagram={data?.instagram}
							linkedin={data?.linkedin}
							facebook={data?.facebook}
						/>
					}
					<div className={`close-icon ${isPartner ? "svg-black" : "svg-orange"}`} onClick={onClose}>
						<CloseIcon />
					</div>
				</motion.div>
			</motion.div>
		</AnimatePresence>
	);
};
