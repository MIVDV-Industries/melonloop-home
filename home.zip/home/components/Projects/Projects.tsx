import { FC } from "react";
import { SimpleHeader } from "../Layout/SimpleHeader";
import { IArticleSection, IProjectArticles } from "../Sections/WhatWeDoSection";
import Image from "next/image";
import Link from "next/link";
import { getSlugName } from "helpers/slugs";

interface IProjectsProps {
  article: IArticleSection;
  onBack: () => void;
}

export const Projects: FC<IProjectsProps> = ({ article, onBack }) => {
  return (
    <div className="projects-wrapper">
      <SimpleHeader title={article.name} onBack={onBack} />
      <div className="projects-showcase">
        {article.projects.map((project) => (
          <ProjectCard key={project.name} article={article.name} project={project} />
        ))}
      </div>
    </div>
  );
};

const ProjectCard = ({ project, article }: { project: IProjectArticles, article: string }) => {

  const slug = getSlugName(article, project.name);
  
  return (
    <Link href={`projects/${slug}`}>
      <div className="project-card">
          <Image
            src={project.image.src}
            alt={project.image.alt}
            width="100%"
            height="100%"
            layout="responsive"
            objectFit="contain"
            priority={true}
            />
          <div className="project-info">
            <h3 className="project-name">{project.name}</h3>
            <h4 className="project-type">{project.type}</h4>
          </div>
          <h4 className="project-desc">{project.desc}</h4>
      </div>
    </Link>
  );
};
