import { LoaderIcon } from "components/Icons"
import { FC } from "react"
import { AnimatePresence, motion, Transition } from 'framer-motion'

const transitionOptions: Transition = {
	type: "spring",
	repeat: Infinity,
	repeatType: "mirror",
	damping: 20,
	duration: 1.3,
	mass: 1,
	stiffness: 300
}

export const Loader: FC<{ loading: boolean }> = ({ loading }) => {
	return (
		<AnimatePresence>
			{loading && <motion.div className="loader-background" exit={{ opacity: 0 }}>
				<motion.div
					animate={{ rotate: 180 }}
					transition={transitionOptions}
					className="loader-wrapper"
				>
					<LoaderIcon />
				</motion.div>
			</motion.div>}
		</AnimatePresence>
	)
}
