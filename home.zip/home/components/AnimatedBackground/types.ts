import { MeshBasicMaterial, Vector3 } from "three"

export type propTypes = {
  mousePosition: Vector3
  originPosition: Vector3
  material: MeshBasicMaterial
  rotationSpeed: number
  clicked: boolean
  isMobile: boolean
}