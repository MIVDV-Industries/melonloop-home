
// ==> Helper functions

import { Vector3 } from "three";

// Lerps between 2 values (start, end) with fraction amt
export const lerp = (start: number, end: number, amt: number): number => {
  return (1-amt)*start+amt*end
}

// Gets point at percentage of distance between pointA and pointB
export const getPointInBetweenByPerc = (pointA: Vector3, pointB: Vector3, percentage: number): Vector3 => {
  let dir = pointB.clone().sub(pointA);
  let len = dir.length();
  dir = dir.normalize().multiplyScalar(len*percentage);
  return pointA.clone().add(dir);
}


