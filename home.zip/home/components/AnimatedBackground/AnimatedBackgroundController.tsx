/* eslint-disable react/no-unknown-property */
// Argue with me about this if u got an issue m8

import {
 useState,
 useEffect,
 useMemo, 
 useRef,
 useTransition
} from "react"
import { useThree, useFrame } from "@react-three/fiber"
import { Vector3, Plane, Ray, MeshLambertMaterial, TextureLoader, Object3D, InstancedMesh, Matrix4 } from "three"


import particles from "data/bgParticles.json"
import { useWindowSize } from "hooks/useWindowSize"
import { paths } from "paths"
import { constants } from "../../constants"
import { getPointInBetweenByPerc, lerp } from "./utils"

// This is an temp object i will perform all the transformations upon so i can then set each of the particles transforms to this one
const tempObject = new Object3D()

// I needed to separate global functionality like mouseposition in this component
// because useThree needs to be used in a component that has Canvas as its parent

export const AnimatedBackgroundController = () => {

  // state
  const [mousePosition, setMousePosition] = useState(new Vector3(0,0,0))

  const [clicked, setClicked] = useState(false)

  // hooks 
  const [isPending, startTransition] = useTransition()
  const meshRef = useRef<InstancedMesh>(null!)

  const { isMobile } = useWindowSize()

  const { camera } = useThree()


  // we load the material ONCE and then use it for all the particles 
  const material = useMemo(() => {
    return new MeshLambertMaterial({ map: new TextureLoader().load(paths.SeedIconPath), transparent: true })
  }, []);

  const computedParticles = useMemo(() => {
    if(!isMobile) {
     return particles.map((particle) => {
      particle.rotationSpeed = Math.random() * 0.02 + 0.01 * (Math.random() > 0.5 ? 1 : -1)
      particle.originPosition[0] = particle.originPosition[0] + Math.random() * 0.3 * (Math.random() > 0.5 ? 1 : -1) 
      particle.originPosition[1] = particle.originPosition[1] + Math.random() * 0.3 * (Math.random() > 0.5 ? 1 : -1) 
      return particle
     })
    } else {
      return particles.map((particle) => {
      return {
        originPosition: [ 
          particle.originPosition[1] * 0.8 + Math.random() * 0.005 * (Math.random() > 0.5 ? 1 : -1), 
          particle.originPosition[0] * 0.8 - 1 + Math.random() * 0.005 * (Math.random() > 0.5 ? 1 : -1)
        ],
        rotationSpeed: Math.random() * 0.02 + 0.01 * (Math.random() > 0.5 ? 1 : -1)
      }
      })
    }
  }, [isMobile])

  // Runs on mount
  useEffect(() => {
    // 👇️ mouse position for bg animation 
    const handleWindowMouseDown = () => {
      setClicked(true)
    }
    const handleWindowMouseUp = () => {
      setClicked(false)
    }

    const handleWindowMouseMove = (event: MouseEvent) => {
      const vector = new Vector3();
      const ray = new Ray();
      const planeZ = new Plane(new Vector3(0, 0, 1),);

      vector.set((event.clientX / window.innerWidth) * 2 - 1, - (event.clientY / window.innerHeight) * 2 + 1, 0.5) // z = 0.5 important!
      vector.unproject(camera)

      ray.set(camera.position, vector.sub(camera.position).normalize())

      const result = new Vector3(0, 0, 0)
      const intersects = ray.intersectPlane(planeZ, result)

      setMousePosition(intersects || result)
    }

    window.addEventListener('mousemove', handleWindowMouseMove)
    window.addEventListener('mousedown', handleWindowMouseDown)
    window.addEventListener('mouseup', handleWindowMouseUp)
    return () => {
      window.removeEventListener('mousemove', handleWindowMouseMove)
      window.removeEventListener('mousedown', handleWindowMouseDown)
      window.removeEventListener('mouseup', handleWindowMouseUp)
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  // Runs on frame
  useFrame((state, delta) => {
      // makes any logic inside of it have lower priority than other operations inside the react tree 
      // (only state changing logic like setstate or changing refs I guess, not sure, research if interested)
      startTransition(() => {
      computedParticles.forEach((particle, index) => {
        let particleMatrix = new Matrix4()
        meshRef.current.getMatrixAt(index, particleMatrix)
        tempObject.position.setFromMatrixPosition(particleMatrix)
        tempObject.rotation.setFromRotationMatrix(particleMatrix)

         tempObject.rotation.z += particle.rotationSpeed
         let targetToLerpTo = new Vector3(0,0,0)

        // this if decides betwen if the particle should lerp to 
        //                                          a) its origin pos 
        //                                          b) away from cursor 
        //                                          c) the current pos so we dont have jitters between the first 2 states
        if(tempObject.position.distanceTo(mousePosition) < constants.PUSH_AWAY_THRESHOLD) {
          if(clicked) {
            targetToLerpTo.x = mousePosition.x
            targetToLerpTo.y = mousePosition.y
          } else {
            const pushToPoint = getPointInBetweenByPerc(mousePosition,tempObject.position, 1.5)

            targetToLerpTo.x = pushToPoint.x
            targetToLerpTo.y = pushToPoint.y
          }
        } else if (tempObject.position.distanceTo(mousePosition) < constants.PUSH_AWAY_THRESHOLD + constants.DEAD_ZONE_THRESHOLD ) {
          targetToLerpTo = tempObject.position
        } else {
          targetToLerpTo.x = particle.originPosition[0] // x
          targetToLerpTo.y = particle.originPosition[1] // y
        }

        // we can now apply the lerp as we decided the point we want to lerp towards in the if above 
        tempObject.position.x = lerp( tempObject.position.x, targetToLerpTo.x, delta * constants.LERP_SPEED)
        tempObject.position.y = lerp( tempObject.position.y, targetToLerpTo.y, delta * constants.LERP_SPEED)
        tempObject.scale.setScalar(isMobile ? 0.35 : 0.5)
        tempObject.updateMatrix()
        meshRef.current.setMatrixAt(index, tempObject.matrix)
        
      })
      meshRef.current.instanceMatrix.needsUpdate = true
    })
  })

  return (
    <group>
      <ambientLight intensity={1000}/>
      <instancedMesh
        ref={meshRef}
        args={[undefined, undefined, computedParticles.length]}
        material={material}
        >
        <planeBufferGeometry args={[1, 1.7, 1]} />
      </instancedMesh> 

    </group>
  )
}