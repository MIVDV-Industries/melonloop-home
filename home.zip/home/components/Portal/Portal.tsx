import { useEffect } from 'react'
import { createPortal } from 'react-dom'
import { FC } from 'react'
import { useWindowSize } from "hooks/useWindowSize"

interface IPortal {
    children?: React.ReactNode;
    show: boolean;
    hideNav?: boolean;
}

export const Portal: FC<IPortal> = ({ children, show, hideNav = true }) => {
    const { width } = useWindowSize();
    useEffect(() => {

        if (!!width && width > 780) {
            const navContainer = document.querySelector('.nav-container');
            const navElements = navContainer && Array.from(navContainer?.children);

            if (show && hideNav) {
                navContainer?.classList.add("hide");
                navElements?.forEach((el) => {
                    el.classList.add("hide")
                })
            } else {
                navContainer?.classList.remove("hide");
                navElements?.forEach((el) => {
                    el.classList.remove("hide")
                })
            }
        }
    }, [show, hideNav, width])


    return show
        ? createPortal(children,
            document.querySelector("#portal-root") as Element)
        : null
}
