import { Member } from "components/Sections/types";
import { motion } from "framer-motion";
import { FC, useEffect, useMemo, useState } from "react";
import Image from "next/image";
import { Socials, PeopleIcon, ExpandIcon } from "@components";

interface HoverableCardProps {
  member: Member;
  isAnySelected: boolean;
  isSelected: boolean;
  handleSelectedMember: (member: Member) => void;
  index: number;
}

interface PlaceholderCardProps {
  isAnySelected: boolean;
  handleClick?: (type: "CONTACT" | "JOIN") => void;
}

export const HoverableCard = ({
  member,
  isAnySelected,
  isSelected,
  handleSelectedMember,
  index,
}: HoverableCardProps) => {
  const [screenW, setScreenW] = useState<number>(0)

  useEffect(() => {
    setScreenW(window?.innerWidth);

    if (window)
      window.addEventListener("resize", () => setScreenW(window?.innerWidth))

    return () => {
      window.removeEventListener("resize", () => setScreenW(window?.innerWidth))
    }
  }, [])

  const animationVariants = useMemo(
    () => ({
      selected: {
        x:
          index < 5
            ? `${-224 * index - 24 * index + 60}px`
            : `${-124 - 224 * (index % 5) - 24 * (index % 5) + 60}px`,
        y: `${-224 * Math.floor(index / 5) - 24 * Math.floor(index / 5 + 1) - 40}px`,
        // SCALE VALUE IS USED TO RENDER THE EXPANDED 'CARD' PROPERLY ON DESKTOP
        // --scale-factor css variable in _hoverableCard.scss
        scale: 1.5,
      },
      unselectedLarge: {
        x: "0",
        scale: 1,
      },
      unselectedSmall: {
        x: index === 4 ? "-125px" : 0,
        y: index < 5 ? "110.5%" : "0",
        scale: 0.5,
      },
    }),
    [index]
  );

  const animationVariantsCard = {
    selected: {
      left: "100%",
      opacity: 1,
      transition: {
        left: {
          duration: 0.5,
          delay: isAnySelected ? 0 : 1.2,
        },
        opacity: {
          duration: 0.5,
          delay: isAnySelected ? 0 : 1.2,
        },
      },
    },
  };

  return (
    <motion.div
      onClickCapture={() => console.log(isAnySelected)}
      key={member.imageUrl}
      animate={
        screenW > 1380 ? isSelected
          ? "selected"
          : isAnySelected
            ? "unselectedSmall"
            : "unselectedLarge" : ""
      }
      variants={animationVariants}
      className={`hoverable-card-container ${member.isSelected
        ? "selected"
        : isAnySelected
          ? "is-other-selected"
          : ""
        }`}
      onClick={() => handleSelectedMember(member)}
    >
      <Image
        src={member.imageUrl}
        alt="member-pic"
        layout="fill"
        priority={true}
      />
      {!isSelected && (
        <div className="hover-overaly-container">
          <div className="hover-overlay">
            <ExpandIcon />
            <div className="title">{member.name}</div>
            <div className="description">{member.role}</div>
          </div>
        </div>
      )}
      {isSelected && (
        <motion.div
          variants={animationVariantsCard}
          animate={isSelected && "selected"}
          className="card"
        >
          <span className="card-name">{member.name}</span>
          <h3>{member.role}</h3>
          <h4 className="card-description">{member.description}</h4>
          <Socials className="card-icons" instagram={member.instagram} facebook={member.facebook} linkedin={member.linkedin} />
        </motion.div>
      )}
    </motion.div>
  );
};

export const PlaceholderCard: FC<PlaceholderCardProps> = ({
  isAnySelected,
  handleClick,
}) => {
  const [screenW, setScreenW] = useState<number>(0)

  useEffect(() => {
    setScreenW(window?.innerWidth);

    if (window)
      window.addEventListener("resize", () => setScreenW(window?.innerWidth))

    return () => {
      window.removeEventListener("resize", () => setScreenW(window?.innerWidth))
    }
  }, [])

  const variations = {
    selectedPlaceholder: {
      scale: 0.5,
      x: "125px",
    },
  };

  return (
    <motion.div
      onClickCapture={() => handleClick && handleClick("JOIN")}
      animate={isAnySelected && screenW > 1380 ? "selectedPlaceholder" : ""}
      variants={variations}
      className="placeholder-card"
    >
      <PeopleIcon />
      Join us!
    </motion.div>
  );
};
