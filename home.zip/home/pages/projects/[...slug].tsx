import { useEffect } from "react";
import { GetStaticPaths, GetStaticProps, NextPage } from "next";
import projectArticles from "data/projectArticles.json";
import { getSlugName } from "helpers/slugs";
import { SimpleHeader, Loader } from "components";
import { useRouter } from 'next/router';
import { ParsedUrlQuery } from "querystring";
import fsPromises from 'fs/promises';
import path from 'path';
import { useContext } from 'react'
import { ApplicationContext } from "context/ApplicationContext";

interface IProjectPageProps {
  title: string;
  type: string;
  banner: IProjectBanner;
  content: string;
}

interface IProjectBanner {
  src: string;
  alt: string;
}

interface IParams extends ParsedUrlQuery {
  slug: string[]
}

const Project: NextPage<IProjectPageProps> = ({ title, type, banner, content }) => {
  const router = useRouter()
  const appContext = useContext(ApplicationContext);

  useEffect(() => {
    // Just because CSS is being a bitch about the 'overflow: hidden' on the body :)
    document.body.style.overflow = "auto";
  }, [])

  return (
    <>
      <Loader loading={appContext?.loading!} />
      {!!appContext && !appContext.loading && <div className="projectPage-container">
        {/* TODO: Replace 'back' with a link to what we do section */}
        <SimpleHeader title={title} onBack={() => router.back()}/>
        <div className="projectPage-content"> 
          <picture className="article-banner">
            <img src={banner.src} alt={banner.alt}/>
          </picture>
          <article>
            <div className="article-title">
              <h3>{title}</h3>
              <h4>{type}</h4>
            </div>
            <div className="article-content" dangerouslySetInnerHTML={{__html: content}} />
          </article>
        </div>
      </div>}
    </>
  );
};

export const getStaticPaths: GetStaticPaths = async () => {
  const slugs: string[] = projectArticles.flatMap((category) =>
    category.projects.map((project) => {
      return getSlugName(category.name, project.name); 
    })
  );

  return {
    paths: slugs.map((slug) => ({ params: { slug: slug.split("/") } })),
    fallback: false,
  };
};

export const getStaticProps: GetStaticProps<IProjectPageProps, IParams> = async ({ params }) => {
  const filePath = path.join(process.cwd(), `/data/projects/${params?.slug![0]}/${params?.slug![1]}.json`)
  const jsonData = await fsPromises.readFile(filePath, 'utf-8');
  const projectData = JSON.parse(jsonData);

  return { 
    props: {
      ...projectData, 
    }
  };
};

export default Project;
