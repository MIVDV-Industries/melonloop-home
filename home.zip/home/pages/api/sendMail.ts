import { Ok } from 'interfaces/ok'
import { NextApiResponse, NextApiRequest } from 'next'
import { sendSESContactMail } from 'services/awsSESClient'

export default async function handler(
  req: NextApiRequest,
  res: NextApiResponse<any>
) {
  const {
    body: { name, email, message },
    method,
  } = req
  
  switch(method) {
    case 'POST': 
      const messageResult: Ok = await sendSESContactMail(name, email, message)
      if(messageResult.ok) { 
      return res.status(200).json({
        message: "Worked"
      })
      } else {
        return res.status(503).json({
          message: "Something went wrong while sending email. Service is currently unavalabile."
        }) 
      }
    default: 
      res.setHeader('Allow', ['POST'])
      res.status(405).end(`Method ${method} Not Allowed`)
      return res
  }

}