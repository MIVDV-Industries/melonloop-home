import "../styles/main.scss";
import type { AppProps } from "next/app";
import { Canvas } from "@react-three/fiber";
import { AppContextProvider } from "context/ApplicationContext";
import { AnimatedBackgroundController } from "components"

function MyApp({ Component, pageProps }: AppProps) {


  return (
    <>
      <AppContextProvider>
        <Component {...pageProps} />
      </AppContextProvider>

      <Canvas
        gl={{
          antialias: false, // antialasing isnt really gonna be noticeable in our case
          depth: false, // whether the drawing buffer has a depth buffer of at least 16 bits.
          powerPreference: "low-power", // indicating what configuration of GPU is suitable for this WebGL context.
          // (high performance/default are not needed as im trying to make this as light as possible)
        }}
        className="animatedBackground"
      >
        <AnimatedBackgroundController />
      </Canvas>
    </>
  );
}

export default MyApp;
