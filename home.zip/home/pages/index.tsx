import {
  useState,
  useRef,
  createRef,
  useCallback,
  useEffect,
  RefObject,
  useContext,
} from "react";
import type { NextPage } from "next";
import Head from "next/head";
import sectionsData from "data/sections.json";
import { Nav, Section, Header, ContactUs, Loader, Portal } from "components";
import { useWindowSize } from "hooks/useWindowSize";
import { useRouter } from "next/router";
import { ApplicationContext } from "context/ApplicationContext";

const observerOptions = {
  threshold: 0.75,
};

const Home: NextPage = () => {
  const appContext = useContext(ApplicationContext);

  const [activeSection, setActiveSection] = useState("home");
  const [showContactSection, setShowContactSection] = useState<"CONTACT" | "JOIN" | false>(false);
  const [hideNav, setHideNav] = useState(false);
  const { isMobile } = useWindowSize();
  const router = useRouter();

  const elementsRef = useRef<RefObject<HTMLElement>[]>(
    sectionsData.sectionNames.map(() => createRef())
  );

  const handleObserver = useCallback((entries: IntersectionObserverEntry[]) => {
    const [entry] = entries;
    setActiveSection(entry.target.id);
  }, []);

  const showContact = (pageName?: "CONTACT" | "JOIN") => {
    setShowContactSection(typeof pageName === "string" ? pageName : "CONTACT");
    setHideNav(true);
    setTimeout(() => window.scrollTo({ top: window.innerHeight, behavior: "smooth" }));
  };

  const closeContact = () => {
    setHideNav(false);
    window.scrollTo({ top: 0, behavior: "smooth" });
    setTimeout(() => setShowContactSection(false), 700);
  };

  useEffect(() => {
    // See comment in 'projects/[...slug].tsx' for why this is necessary 
    document.body.style.overflow = "hidden";
  }, [])

  useEffect(() => {
    const sections = elementsRef.current;
    
    if (!sections || !appContext) return;
    const observer = new IntersectionObserver(handleObserver, observerOptions);

    if (!appContext.loading) {
      sections.forEach((ref) => observer.observe(ref.current as HTMLElement));
      document.getElementById(router.asPath.split("#")[1])?.scrollIntoView({ behavior: "smooth" });
    }

    return () => {
      if (!appContext.loading) observer.disconnect();
    };
  }, [handleObserver, appContext, router]);

  return (
    <>
      <Head>
        <title>melonloop</title>
        <meta
          name="description"
          content="melonloop - building the web one project at a time"
        />
        <link rel="icon" href="/favicon.ico" />
      </Head>

      <Loader loading={appContext?.loading!} />

      <Header activeSection={activeSection} showContactSection={showContact} />
      {!!appContext && !appContext.loading && (
        <main>
          {sectionsData.sectionNames.map((name, index) => (
            <Section
              key={name}
              name={name}
              parentRef={elementsRef.current[index]}
              showPortal={showContact}
            />
          ))}
        </main>
      )}

      {!isMobile ? (
        <Nav activeSection={activeSection} sectionsRef={elementsRef} />
      ) : null}

      <Portal show={!!showContactSection} hideNav={hideNav}>
        <ContactUs
          onBack={closeContact}
          isContact={showContactSection === "CONTACT"}
        />
      </Portal>
    </>
  );
};

export default Home;
