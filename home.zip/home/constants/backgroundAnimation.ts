
export const backgroundAnimationConstants = { 
  PUSH_AWAY_THRESHOLD: 1.1, // size of circle around mouse that pushes away the particles
  DEAD_ZONE_THRESHOLD: 0.20, // size of circle around push away circle where we just leave the particles alone 
  LERP_SPEED: 3, // bigger faster smaller slower
}