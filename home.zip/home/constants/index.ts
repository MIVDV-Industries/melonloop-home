import { backgroundAnimationConstants } from "./backgroundAnimation"

export const constants = {
  ...backgroundAnimationConstants,
}