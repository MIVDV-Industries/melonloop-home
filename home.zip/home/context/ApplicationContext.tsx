import { createContext, useState, useEffect, FC, useRef } from "react";

interface IApplicationContext {
  loading: boolean;
}

interface IContextProps {
  children: React.ReactNode;
}

export const ApplicationContext = createContext<IApplicationContext | null>(null);

export const AppContextProvider: FC<IContextProps> = ({ children }) => {
  const [loading, setLoading] = useState(true);

  // Ensures a min of 2 second and a max of 5 seconds for the loading animation
  // Also, it is a ref so it does not re-render unnecessarily
  const loaderTime = useRef(Math.random() * 3000 + 2000);

  useEffect(() => {
    setLoading(true);
    setTimeout(() => {
      setLoading!(false);
    }, loaderTime.current);
  }, []);

  return (
    <ApplicationContext.Provider value={{ loading }}>
      {children}
    </ApplicationContext.Provider>
  );
};
