// aws-ses.js
import * as AWS from "aws-sdk";
import * as nodemailer from "nodemailer";
import { buildTemplateFrom } from "../templates/emailTemplate"

// => update the creds and region
AWS.config.update({
  accessKeyId: process.env.SES_ACCESS_KEY,
  secretAccessKey: process.env.SES_SECRET_ACCESS_KEY,
  region: "eu-central-1",
})

// => check if creds are valid 
AWS.config.getCredentials(function (error) {
  if (error) {
    console.log(error.stack);
  }
})

// => init SES
const ses = new AWS.SES({ apiVersion: "2010-12-01" });

// => change this to the "to" email that you want
const adminMail = "front@melonloop.com"

// => Create a transporter of nodemailer
const transporter = nodemailer.createTransport({
  SES: ses,
})

export const sendSESContactMail = async (name: string, email: string, message: string) => {
  try {

    const response = await transporter.sendMail({
      from: adminMail,
      to: process.env.MAIL_ADDRESS_TO_SEND_CONTACT_EMAILS_TO,
      subject: `Message from ${name}`,
      html: buildTemplateFrom(name, email, message),
    })

    return response?.messageId ? { ok: true } : { ok: false }

  } catch (error) {
    throw error
  }
}