export const buildTemplateFrom = (name: string, email: string, message: string) => 
`<html>
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <style>
      body {
        display: flex;
        flex-flow: column nowrap;
        gap: 1em;
      }
    </style>
  </head>
  <body>
    <span> Message sent using the contact form on <a href="https://www.melonloop.com">melonloop</a></span>
    <br />
    <br />
    <span>From: <b>${name}</b></span> <br /><br />
    <span>Email: <b>${email}</b></span> <br /><br />
    <span>Message:<br /> 
      <b>${message}</b>
    </span>
  </body>
</html>`