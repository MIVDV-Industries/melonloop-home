export type Ok = {
  ok: boolean
}