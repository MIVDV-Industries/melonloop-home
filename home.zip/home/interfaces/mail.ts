export type MailData = {
  name: string
  email: string
  message: string
}